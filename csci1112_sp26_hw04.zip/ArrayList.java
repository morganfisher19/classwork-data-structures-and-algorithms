/*--------------------------------------------------------------------------
GWU - CS1112 Data Structures and Algorithms - Spring 2026

TODO : Document this file

authors: <TODO your name here>, Charles Peeke
--------------------------------------------------------------------------*/
public class ArrayList implements MusicCatalog {
    // For an array-based list, the array itself
    private CatalogItem[] data;
    // The counter to track the number of elements in the list
    private int count;

    // Parameterless Constructor
    public ArrayList() {
        count = 0;
        data = new CatalogItem[2];
    }
   
    /// TODO : Document this function
    public void add(Song song) {
        // TODO : Implement this function
    }

    /// TODO : Document this function
    public Song remove() {
        // TODO : Implement this function

        return null;
    }

    /// TODO : Document this function
    public Song remove(Song song) {
        // TODO : Implement this function

        return null;
    }
    
    /// TODO : Document this function
    public void clear() {
        // TODO : Implement this function
    }
    
    /// TODO : Document this function
    public boolean isEmpty() {
        // TODO : Implement this function

        return false;
    }
    
    /// TODO : Document this function
    public int count() {
        // TODO : Implement this function

        return 0;
    }
    
    /// TODO : Document this function
    public Song get(int i) {
        // TODO : Implement this function

        return null;
    }

    /// TODO : Document this function
    public boolean contains(Song song) {
        // TODO : Implement this function

        return false;
    }

    //-----------------------------------------------------------------
    // Utilities
    //-----------------------------------------------------------------

    /// TODO Any private helper functions go here.  They must be documented


    /// Returns a truth value indicating whether the catalog's structural
    /// integrity remains valid.  If the integrity is no longer valid,
    /// then the catalog should be invalidated and usage should not be 
    /// trusted
    /// @return true if the catalog integrity is valid; otherwise, false
    public boolean isIntegrityValid() {
        if(count < 0) {
            return false;
        }
        if(data == null) {
            return false;
        }
        if(count > data.length) {
            return false;
        }
        for(int i = 0; i < count; i++) {
            if(data[i] == null) {
                return false;
            }
        }

        return true;
    }

    /// Returns a string that contains information about the list and the 
    /// contents of the list.  This is mostly useful for visual debugging 
    /// @return a string containing information about the contents of the 
    ///         catalog
    public String toString() {
        String s = "";
        s = "ArrayList::allocated=" + data.length;
        s += ", count=" + count(); 
        s += ", isEmpty=" + isEmpty(); 
        s += ", ["; 
        for(int i = 0; i < count; i++) {
            if(i > 0) {
                s += ", ";
            }
            s += data[i].getSong().getTitle();
            s += " | ";
            s += data[i].getSong().getYear();
        }
        s += "]";
        return s;
    }

    /// Returns the earliest and most recent years of all the songs in the
    /// catalog and then clears the catalog of all songs
    /// @return an array of the years of the earliest and most recent songs
    public int[] publish() {
        int oldYear = Integer.MAX_VALUE;
        int newYear = Integer.MIN_VALUE;

        for(int i = 0; i < count; i++) {
            int curYear = data[i].getSong().getYear();
            if (curYear < oldYear) oldYear = curYear;
            if (curYear > newYear) newYear = curYear;
        }
        clear();
        return new int[] { oldYear, newYear };
    }

}
